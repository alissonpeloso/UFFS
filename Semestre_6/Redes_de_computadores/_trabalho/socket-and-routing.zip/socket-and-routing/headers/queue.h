#ifndef QUEUE_H
#define QUEUE_H

#include "packet.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Utilizado para implementação de filas

typedef struct node {
	Packet data;
	struct node *next;
	struct node *prev;
} Node;

typedef struct queue {
	Node *head;
	Node *tail;
	int size;
} Queue;

Queue *initQueue(Queue *queue);

Queue *addQueue(Queue *queue, Packet data);

Queue *rmQueue(Queue *queue);

void printQueue(Queue *queue);

#endif
