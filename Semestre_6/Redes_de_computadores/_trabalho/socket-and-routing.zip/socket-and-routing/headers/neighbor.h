#ifndef NEIGHBOR_H
#define NEIGHBOR_H

typedef struct neighbor{
    int id;
	int port;
	char ip[15];
	int cost;
	int path;
} Neighbor;

#endif
