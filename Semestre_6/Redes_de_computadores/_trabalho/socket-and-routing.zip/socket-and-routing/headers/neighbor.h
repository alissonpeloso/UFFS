#ifndef NEIGHBOR_H
#define NEIGHBOR_H

// Utilizado para armazenar informações dos roteadores vizinhos
typedef struct neighbor{
    int id;
	int port;
	char ip[15];
	int cost;
	bool directLink;
} Neighbor;

#endif
