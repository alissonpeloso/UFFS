#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void printRed();

void printYellow();

void printBlue();

void printGreen();

void printReset();

#endif
