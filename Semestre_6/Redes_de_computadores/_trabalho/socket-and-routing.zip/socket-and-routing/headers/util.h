#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Impressões coloridas
void printRed();

void printYellow();

void printBlue();

void printGreen();

void printReset();

void die(char *s); // Função utilizada na parte dos sockets

#endif
