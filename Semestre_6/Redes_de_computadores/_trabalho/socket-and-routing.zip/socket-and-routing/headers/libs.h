#ifndef LIBS_H
#define LIBS_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include "packet.h"
#include "queue.h"
#include "neighbor.h"
#include "util.h"

// rot functions
void *receiver(void *data); 
void *sender(void *data) ;
void *packet_handler(void *data);
void *terminal(void *data);
void getRotConfig(int id);
void getNeighborsInfo(int id);
void die(char *s);
void menu();
void sendMessage();
void printKnownNeighbors();
void addPacketToQueue(Packet * packet, Queue * queue, int type);

#endif
