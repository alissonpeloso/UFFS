#ifndef PACKET_H
#define PACKET_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Estrutura do pacote
typedef struct packet{
	int id;
    int type; /*0 = message, 1 = control*/
    int sourceId;
    int destinationId;
    char payload[100];
} Packet;

void createPacket(int id, Packet * newPacket, int type, int sourceId, int destinyId, char * payload);

#endif
