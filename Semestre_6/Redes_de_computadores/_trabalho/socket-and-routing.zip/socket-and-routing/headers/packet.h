#ifndef PACKET_H
#define PACKET_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct packet{
    int type; /*0 = message, 1 = control*/
    int sourceId;
    int destinyId;
    char payload[100];
} Packet;

void createPacket(Packet * newPacket, int type, int sourceId, int destinyId, char * payload);

#endif
