# socket-and-routing
Esse repositório trata de um Trabalho de implementação para prática de uso de sockets e simulação de uma rede de roteamento para a CCR: Redes de Computadores – 2021.2

### Descrição

A ideia do programa é executar processos representando os roteadores (nós) da rede, os quais trocarão pacotes de roteamento via sockets UDP. Na versão final do
trabalho, os nós executarão o algoritmo Bellman-Ford distribuído para computar as
suas tabelas de roteamento.

---

## Informações

### 1. Pré-requisitos

Você precisa do GCC Compiler para compilar o programa: [tutorial](https://linuxize.com/post/how-to-install-gcc-compiler-on-ubuntu-18-04/), caso necessário

### 2. Compilar e Rodar

As informações a seguir são essenciais para a utilização do programa.

#### 2.1 Compilar

Para compilar, você deve estar na **pasta raiz** do repositório e rodar:
```
gcc rot.c modules/*.c -o rot.run -lpthread
```

#### 2.2 Executar

Para executar, você deve rodar o comando de execução seguido do **ID** do roteador a ser simulado na sua máquina.

```
./rot.run <ID>
```

Ou seja, se o **ID** do roteador a ser simulado é 1, o comando será esse:

```
./rot.run 1
```

### 3. Utilização

Ao rodar o programa, para acessar ao um menu no terminal, você deve teclar `enter`. A partir do menu, você pode:

1. Enviar mensagem para outro roteador
2. Visualizar os últimos vetores distância recebidos
3. Alterar o tempo de intervalo de envio do vetor distância para os demais roteadores e como consequência alterar o tempo de tolerância para identificação de queda de enlace.
   ```
   Tolerância = 6 * Tempo_de_Intervalo
   ```  

Para parar a execução do programa, você pode digitar `10` na seleção de menu ou utilizar o `ctrl+c`.

**OBS:** Você receberá informações de mensagens **recebidas** e **enviadas** e receberá na tela a tabela de roteamento quando ela for alterada.