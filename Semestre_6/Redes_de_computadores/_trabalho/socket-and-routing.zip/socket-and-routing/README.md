# socket-and-routing
Trabalho de implementação para prática de uso de sockets e simulação de uma rede de roteamento para a CCR: Redes de Computadores – 2021.2

## Comando
```
gcc rot.c modules/*.c -o rot.exe -lpthread
```