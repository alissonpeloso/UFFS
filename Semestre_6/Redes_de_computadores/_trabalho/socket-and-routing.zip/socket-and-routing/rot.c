#include "headers/libs.h"
#include "headers/util.h"

#define N_THREADS 4
#define BUFLEN sizeof(Packet)

int thisRotId;
int thisRotPort;
char *thisRotIp;
int *enlacesInfo = NULL;
int nNeighbors = 0;
Neighbor *neighbors;

Queue *inputQueue;
Queue *outputQueue;

pthread_mutex_t inputQueueMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t outputQueueMutex = PTHREAD_MUTEX_INITIALIZER;

sem_t inputQueueSemaphore;
sem_t outputQueueSemaphore;

int main(int argc, char *argv[])
{
	if(argc != 2){
		printRed();
		printf("ERRO: Você deve usar: ./rot <rot_id>\n");
		printReset();
		exit(1);
	}
	getRotConfig(atoi(argv[1]));

	getNeighborsInfo(atoi(argv[1]));

	pthread_t pthreads[N_THREADS];

	sem_init(&inputQueueSemaphore, 0, 0);
	sem_init(&outputQueueSemaphore, 0, 0);

	inputQueue = initQueue(inputQueue);
	outputQueue = initQueue(outputQueue);

	pthread_create(&pthreads[0], NULL, receiver, NULL);
	pthread_create(&pthreads[1], NULL, sender, NULL);
	pthread_create(&pthreads[2], NULL, packet_handler, NULL);
	pthread_create(&pthreads[3], NULL, terminal, NULL);

	for(int i = 0; i < N_THREADS; i++) {
		pthread_join(pthreads[i], NULL);
	}

	return 0;
}

// ##### Receiver Thread #####
void *receiver(void *data) 
{
	struct sockaddr_in si_me, si_other;
    int s, i, recv_len;
	socklen_t slen = sizeof(si_other);
    char buf[BUFLEN];
     
    //create a UDP socket
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        die("socket");
    }
     
    // zero out the structure
    memset((char *) &si_me, 0, sizeof(si_me));
     
    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(thisRotPort);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);
     
    //bind socket to port
    if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1){
        die("bind");
    }
     
    //keep listening for data
    while(1){
        fflush(stdout);
        //receive a reply and print it
        //clear the buffer by filling null, it might have previously received data
        memset(buf,'\0', BUFLEN);

        //try to receive some data, this is a blocking call
        if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == -1){
            die("recvfrom()");
        }

		Packet receivedPacket;
		sscanf(buf, "%d/;%d/;%d/;%[^/;]", &receivedPacket.type, &receivedPacket.sourceId, &receivedPacket.destinyId, receivedPacket.payload);

		//print details of the client/peer and the data received
	    printf("\n\n----------------------------------------------------------------------------\n");
		printGreen();
        printf("Pacote recebido de %s:%d\n", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
		printReset();
		if(receivedPacket.type == 0){
			printf("Tipo: Mensagem\n");
		} else if(receivedPacket.type == 1){
			printf("Tipo: Controle\n");
		}
		printf("Origem: ID = %d, IP = %s, Port = %d\n", receivedPacket.sourceId, neighbors[receivedPacket.sourceId].ip, neighbors[receivedPacket.sourceId].port);
        printf("Mensagem: %s\n" , receivedPacket.payload);
	    printf("----------------------------------------------------------------------------\n\n");

		if(pthread_mutex_lock(&inputQueueMutex) == 0){
			inputQueue = addQueue(inputQueue, receivedPacket);
			pthread_mutex_unlock(&inputQueueMutex);
			sem_post(&inputQueueSemaphore);
			menu();
		}
    }
	return NULL;
}

// ##### Sender Thread #####
void *sender(void *data) 
{
    struct sockaddr_in si_other;
	int s, slen=sizeof(si_other);
    char message[BUFLEN];

	if ( (s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        die("socket");
    }

	while(1){
		sem_wait(&outputQueueSemaphore);
		
		if(pthread_mutex_lock(&outputQueueMutex) == 0){
			Packet * toSendPacket = &outputQueue->head->data;
			int destinyId = neighbors[toSendPacket->destinyId].path; 

			sprintf(message, "%d/;%d/;%d/;%s/;", toSendPacket->type, toSendPacket->sourceId, toSendPacket->destinyId, toSendPacket->payload);

			memset((char *) &si_other, 0, sizeof(si_other));
			si_other.sin_family = AF_INET;
			si_other.sin_port = htons(neighbors[destinyId].port);

			if (inet_aton(neighbors[destinyId].ip , &si_other.sin_addr) == 0) {
				printRed();
				fprintf(stderr, "inet_aton() failed\n");
				printReset();
				exit(1);
			}

			//send the message
			if (sendto(s, message, strlen(message) , 0 , (struct sockaddr *) &si_other, slen)==-1){
				die("sendto()");
			}

			outputQueue = rmQueue(outputQueue);
			pthread_mutex_unlock(&outputQueueMutex);
		} 
    }
    return NULL;
}

// ##### Packet Handler Thread #####
void *packet_handler(void *data) 
{
	// printf("Estou tratando os pacotes\n");
	return NULL;
}

// ##### Terminal Thread #####
void *terminal(void *data) 
{
	int op = 0;

	while (op != 10){
        menu();
	    scanf("%d", &op);
        switch (op){
			case 1:
				sendMessage();
				break;
			case 10:
				system("exit");
			default:
				printRed();
				printf("\nERRO: Essa opção não existe\n");
				printReset();
        }
    }
	return NULL;
}

// ##### Terminal Functions #####
void menu() 
{
    printf("----------------------------------------------------------------------------\n");
    printf("1 - Enviar Mensagem\n10 - Sair\n");
    printf("----------------------------------------------------------------------------\n");
    printf("\nOpção desejada: ");

    return;
}

void sendMessage() 
{
	int op = 0;

	while (op != -1)
    {
		printKnownNeighbors();

		printf("\nInsira o ID do vizinho ao qual você deseja enviar a mensagem: ");
		scanf("%d", &op);

		if(op > nNeighbors || op < 1 || neighbors[op].id < 1 ){
			printRed();
			printf("ERRO: Este vizinho não existe ou não é conhecido. Tente Novamente!\n");
			printReset();
		} else {
			char message[100];
			printf("Insira a mensagem que deseja enviar (máximo de 100 caracteres): ");
			__fpurge(stdin);
			scanf("%[^\n]s",message);
			__fpurge(stdin);

			Packet newPacket;
			createPacket(&newPacket ,0, thisRotId, op, message);

			if(pthread_mutex_lock(&outputQueueMutex) == 0){
				outputQueue = addQueue(outputQueue, newPacket);
				pthread_mutex_unlock(&outputQueueMutex);
				sem_post(&outputQueueSemaphore);
			}

			return;
		}   
    }	
}

void printKnownNeighbors() 
{
	printf("\nVisinhos conhecidos:\n");
	printf("-----------------------------------------------------------------------------------------\n");
	printf("|\tID\t|\tPort\t|\tIP Address\t|\tCost\t|\tPath\t|\n");
	printf("----------------+---------------+-----------------------+---------------+---------------|\n");
	for(int i = 0; i < nNeighbors; i++){
		if(neighbors[i].id > 0){
			printf("|\t%d\t|\t%d\t|\t%s\t|\t%d\t|\t%d\t|\n",neighbors[i].id, neighbors[i].port, neighbors[i].ip, neighbors[i].cost, neighbors[i].path);
		}
	}
	printf("-----------------------------------------------------------------------------------------\n");
}

// ##### Get initial config #####
void getRotConfig(int id)
{
	int finded = 0;

	FILE *rotConfigFile = fopen("config/roteador.config", "r"); 
	if (rotConfigFile == NULL){
		printRed();
		printf("ERRO: Problemas na abertura do arquivo 'roteador.config'\n");
		printReset();
		exit(1);
	}

	int biggest = -1;
	int tempInfo[2];
	char tempRotIP[15];
	while(fscanf(rotConfigFile, "%i %i %s", &tempInfo[0], &tempInfo[1], tempRotIP) != EOF){
		if(tempInfo[0]+1 > biggest){
			biggest = tempInfo[0]+1;
		}
		if(tempInfo[0] == id){
			finded = 1;
			thisRotId = tempInfo[0];
			thisRotPort = tempInfo[1];
			thisRotIp = tempRotIP;
		}
	}

	neighbors = calloc(sizeof(Neighbor), biggest);
	nNeighbors = biggest;

	if(!finded){
		printRed();
		printf("ERRO: Não foi encontrado o roteador de id %i no arquivo 'roteador.config'\n", id);
		printReset();
		exit(1);
	}

	fclose(rotConfigFile);
}

void getNeighborsInfo(int id)
{
	FILE *enlacesConfigFile = fopen("config/enlaces.config", "r");
	if (enlacesConfigFile == NULL){
		printRed();
		printf("ERRO: Problemas na abertura do arquivo 'enlaces.config'\n");
		printReset();
		exit(1);
	}
	int tempInfo[3];


	while(fscanf(enlacesConfigFile, "%i %i %i", &tempInfo[0], &tempInfo[1], &tempInfo[2]) != EOF){
		if(tempInfo[0] == id || tempInfo[1] == id){	
			int neighborId;
			if(tempInfo[0] == id){
				neighborId = tempInfo[1];
			} else if(tempInfo[1] == id){
				neighborId = tempInfo[0];
			}

			Neighbor newNeighbor;
			newNeighbor.cost = tempInfo[2];
			newNeighbor.path = neighborId;

			FILE *rotConfigFile = fopen("config/roteador.config", "r"); 
			if (rotConfigFile == NULL){
				printRed();
				printf("ERRO: Problemas na abertura do arquivo 'roteador.config'\n");
				printReset();
				exit(1);
			}

			while(fscanf(rotConfigFile, "%i %i %s", &newNeighbor.id, &newNeighbor.port, newNeighbor.ip) != EOF){
				if(newNeighbor.id == neighborId){
					neighbors[neighborId] = newNeighbor;
					break;
				}
			}

			fclose(rotConfigFile);
		}
	}

	fclose(enlacesConfigFile);
}