#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "headers/libs.h"
#include "headers/util.h"

#define N_THREADS 5
#define BUFLEN sizeof(Packet)
#define INFINITY INT_MAX

int thisRotId;
int thisRotPort;
char *thisRotIp;
int *enlacesInfo = NULL;
int nNeighbors = 0;
Neighbor *neighbors;
int timeout = 5;
int countToInfinity;
int newId = 1;

int ** distanceArrays;
int nDistanceArrays = 0;
int *sizeEachDistanceArray;

int ** routingTable;
int nRoutingTable = 0;

time_t *countdownDistanceArrays;
int sizeCountdownDA = 0;

Queue *inputQueue;
Queue *outputQueue;

pthread_mutex_t inputQueueMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t outputQueueMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t neighborsMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t distanceArraysMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t routingTableMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t countdownDistanceArraysMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t newIdMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t terminalMutex = PTHREAD_MUTEX_INITIALIZER; 
sem_t inputQueueSemaphore;
sem_t outputQueueSemaphore;

struct sockaddr_in si_me, si_other;
int s, i, recv_len;
socklen_t slen = sizeof(si_other);
char buf[BUFLEN];

int main(int argc, char *argv[])
{
	if(argc != 2){ // Verifica argumentos da execução
		printRed();
		printf("ERRO: Você deve usar: ./rot <rot_id>\n");
		printReset();
		exit(1);
	}
	// Pega informação do roteador indicado pelo argumento na execução
	getRotConfig(atoi(argv[1])); 

	// Pega informação dos roteadores vizinhos
	getNeighborsInfo(atoi(argv[1])); 

	// Cria o Socket UDP
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1){
        die("socket");
    }
     
    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(thisRotPort);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);

    // Faz a conexão do soquete com a porta
    if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1){
        die("bind");
    }

	pthread_t pthreads[N_THREADS];

	// Inicia os semáforos da fila de entrada e saída
	sem_init(&inputQueueSemaphore, 0, 0); 
	sem_init(&outputQueueSemaphore, 0, 0);

	// Inicia as filas de entrada e saída
	inputQueue = initQueue(inputQueue); 
	outputQueue = initQueue(outputQueue);

	// Cria as threads
	pthread_create(&pthreads[0], NULL, receiver, NULL);
	pthread_create(&pthreads[1], NULL, sender, NULL);
	pthread_create(&pthreads[2], NULL, packet_handler, NULL);
	pthread_create(&pthreads[3], NULL, terminal, NULL);
	pthread_create(&pthreads[4], NULL, control_messages, NULL);

	// Inicia as threads
	for(int i = 0; i < N_THREADS; i++) {
		pthread_join(pthreads[i], NULL);
	}

	return 0;
}

// ##### Receiver Thread #####
void *receiver(void *data) 
{    
	// Zera a estrutura
    memset((char *) &si_me, 0, sizeof(si_me));
	     
	// Aguarda o recebimento de mensagens
    while(1){
        fflush(stdout);
        // Limpa o buffer
        memset(buf,'\0', BUFLEN);

        // Tenta receber dados, chamada bloqueante
        if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == -1){
            die("recvfrom()");
        }

		// Cria pacote com informações recebidas
		Packet receivedPacket;
		sscanf(buf, "%d/;%d/;%d/;%d/;%[^/;]", &receivedPacket.id, &receivedPacket.type, &receivedPacket.sourceId, &receivedPacket.destinationId, receivedPacket.payload);

		if(pthread_mutex_trylock(&terminalMutex) == 0) {
			printf("\n----------------------------------------------------------\n");
			printGreen();
			printf("Pacote recebido de %s:%d", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
			printReset();

			// Imprime detalhes do pacote recebido
			printGreen();
			printf("\n\n*** PACOTE RECEBIDO ***\n");
			printReset();
			if(receivedPacket.type == 0){
				printf("Tipo: Mensagem\n");
			} else if(receivedPacket.type == 1){
				printf("Tipo: Controle\n");
			}
			printf("ID: %d\nOrigem: ID = %d\nDestino: ID = %d\n", receivedPacket.id, receivedPacket.sourceId, receivedPacket.destinationId);
			printf("Mensagem: %s\n" , receivedPacket.payload);
			printf("----------------------------------------------------------\n\n");

			pthread_mutex_unlock(&terminalMutex);
		}

		// Adiciona pacote criado na fila de entrada
		if(pthread_mutex_lock(&inputQueueMutex) == 0){
			inputQueue = addQueue(inputQueue, receivedPacket);
			pthread_mutex_unlock(&inputQueueMutex);
			sem_post(&inputQueueSemaphore);
		}
    }
	return NULL;
}

// ##### Sender Thread #####
void *sender(void *data) 
{
    char message[BUFLEN];

	while(1){
		// Verifica se há algum pacote na fila de saída, chamada bloqueante
		sem_wait(&outputQueueSemaphore);

		// Cria pacote que receberá as informações a serem enviadas
		Packet toSendPacket;
		if(pthread_mutex_lock(&outputQueueMutex) == 0){ // Verifica se outra thread está usando a fila de saída, chamada bloqueante
			// Cria ponteiro para pacote a ser enviado
			Packet * headPacket = &outputQueue->head->data;
			toSendPacket.id = headPacket->id;
			toSendPacket.type = headPacket->type;
			toSendPacket.sourceId = headPacket->sourceId;
			toSendPacket.destinationId = headPacket->destinationId;
			strcpy(toSendPacket.payload, headPacket->payload);

			// Remove o pacote da fila de saída
			outputQueue = rmQueue(outputQueue);
			pthread_mutex_unlock(&outputQueueMutex); // Libera o mutex
		}
		
		int destinationId, port;
		char ip[15];

		if(toSendPacket.type == 1) { // Se for mensagem de controle, usa enlace direto
			destinationId = toSendPacket.destinationId;
		} else {
			if(pthread_mutex_lock(&routingTableMutex) == 0){
				destinationId = routingTable[toSendPacket.destinationId][1]; // Pega informação de destino
				pthread_mutex_unlock(&routingTableMutex);
			}
		}

		// Pega informação de Porta e IP
		if(pthread_mutex_lock(&neighborsMutex) == 0){
			port = neighbors[destinationId].port;
			strcpy(ip, neighbors[destinationId].ip);
			pthread_mutex_unlock(&neighborsMutex);
		}

		// Converte o pacote para formato em string
		sprintf(message, "%d/;%d/;%d/;%d/;%s/;", toSendPacket.id, toSendPacket.type, toSendPacket.sourceId, toSendPacket.destinationId, toSendPacket.payload);

		// Configura informações de envio
		memset((char *) &si_other, 0, sizeof(si_other));
		si_other.sin_family = AF_INET;
		si_other.sin_port = htons(port);

		if (inet_aton(ip , &si_other.sin_addr) == 0) {
			printRed();
			fprintf(stderr, "inet_aton() failed\n");
			printReset();
			exit(1);
		}

		// Envia a Mensagem
		if (sendto(s, message, strlen(message) , 0 , (struct sockaddr *) &si_other, slen)==-1){
			die("sendto()");
		}

		// Imprime detalhes do pacote recebido
		if(pthread_mutex_trylock(&terminalMutex) == 0) {
			printf("\n----------------------------------------------------------\n");
			printGreen();
			printf("*** PACOTE ENVIADO ***\n");
			printReset();
			if(toSendPacket.type == 0){
				printf("Tipo: Mensagem\n");
			} else if(toSendPacket.type == 1){
				printf("Tipo: Controle\n");
			}
			printf("ID: %d\nOrigem: ID = %d\nDestino: ID = %d\n", toSendPacket.id, toSendPacket.sourceId, toSendPacket.destinationId);
			printf("Mensagem: %s\n" , toSendPacket.payload);
			printf("----------------------------------------------------------\n\n");

			pthread_mutex_unlock(&terminalMutex);
		}
    }
    return NULL;
}

// ##### Packet Handler Thread #####
void *packet_handler(void *data) 
{
	setRoutingTable();
	while(1) {
		// Verifica se há algum pacote na fila de entrada, chamada bloqueante
		sem_wait(&inputQueueSemaphore);

		Packet toHandlePacket;
		if(pthread_mutex_lock(&inputQueueMutex) == 0){ // Verifica se outra thread está usando a fila de entrada, chamada bloqueante

			// Pega pacote a ser tratado e faz uma cópia
			Packet * headPacket = &inputQueue->tail->data;

			toHandlePacket.id = headPacket->id;
			toHandlePacket.type = headPacket->type;
			toHandlePacket.sourceId = headPacket->sourceId;
			toHandlePacket.destinationId = headPacket->destinationId;
			strcpy(toHandlePacket.payload, headPacket->payload);

			// Remove pacote da fila de entrada
			inputQueue = rmQueue(inputQueue);
			pthread_mutex_unlock(&inputQueueMutex);
		}

		if(toHandlePacket.type == 1) { // Mensagem de Controle
			// Configura o vetor de tempos restantes
			setCountdownDistanceArray(toHandlePacket.sourceId);

			// Configura os Vetores de Distância de acordo com o que recebeu
			setDistanceArray(&toHandlePacket);

			// Configura a tabela de roteamento
			setRoutingTable();
		} else if(toHandlePacket.type == 0 && toHandlePacket.destinationId != thisRotId){ // Verifica se precisa reencaminhar a mensagem
			if(pthread_mutex_trylock(&terminalMutex) == 0) {
				printBlue();
				printf("Roteador %d encaminhando mensagem #%d para o destino %d\n" ,thisRotId, toHandlePacket.id, toHandlePacket.destinationId);
				printReset();

				pthread_mutex_unlock(&terminalMutex);
			}

			// Adiciona o Pacote na fila de Saída
			if(pthread_mutex_lock(&outputQueueMutex) == 0){
				outputQueue = addQueue(outputQueue, toHandlePacket);
				pthread_mutex_unlock(&outputQueueMutex);
				sem_post(&outputQueueSemaphore);
			}
		}
	}

}

// ##### Control Messages Thread #####
void *control_messages(void *data) 
{
	while(1){
		int currentTimeout;

		// Pega informação do timeout
		if(pthread_mutex_lock(&countdownDistanceArraysMutex) == 0){
			currentTimeout = timeout;
			pthread_mutex_unlock(&countdownDistanceArraysMutex);
		}

		// Dorme durante o timeout
		sleep(currentTimeout);

		// Atualiza a tabela antes de enviar o vetor distância
		setRoutingTable();

		// Envia vetor distância depois do timeout
		sendDistanceArray();
	}
}

// ##### Terminal Thread #####
void *terminal(void *data) 
{
	int op = 0;

	while (op != 10){
		// Aguarda a tecla enter
		while(1) {
			__fpurge(stdin);
			int key = getchar();
			if(key == 10 || key == 13) {
				break;
			}
		}
		if(pthread_mutex_lock(&terminalMutex) == 0) { // Chamada bloqueante para o mutex de visualização do terminal
			menu();
			scanf("%d", &op);
			switch (op){
				case 1:
					// Enviar mensagem criada pelo usuário
					sendMessage();
					break;
				case 2:
					// Imprime os últimos vetores distância recebidos
					printDistanceArrays();
					break;
				case 3:
					// Altera tempo de espera entre os envios de vetor distância configuradas pelo usuário
					changeTimeout();
					break;
				case 4:
					// Imprime a tabela de roteamento atual
					printRoutingTable();
					break;
				case 10:
					// Desliga o roteador (para a execução)
					exit(1);
				default:
					printRed();
					printf("\nERRO: Essa opção não existe\n");
					printReset();
			}
			pthread_mutex_unlock(&terminalMutex);
		}
    }
	return NULL;
}

// ##### Terminal Functions #####
void menu() 
{
	printf("----------------------------------------------------------------------------\n");
	printf("1 - Enviar Mensagem\n2 - Ver últimos vetores distância recebidos\n3 - Alterar tempo de intervalo de envio dos Vetores Distância\n4 - Ver tabela de Roteamento\n10 - Desligar Roteador\n");
	printf("----------------------------------------------------------------------------\n");
	printf("\nOpção desejada: ");

    return;
}

// Envia a mensagem criada pelo usuário
void sendMessage() 
{
	int op = 0;

	while (op != -1)
    {
		// Mostra os destinos possíveis
		printKnownNeighbors();

		// Pede ID do destino ao usuário
		printf("\nInsira o ID do vizinho ao qual você deseja enviar a mensagem: ");
		scanf("%d", &op);

		// Pega informações do destino escolhido
		int tempNNeighbors, tempIdNeighbor, tempCostNeighbor = INFINITY;
		if(pthread_mutex_lock(&routingTableMutex) == 0) {
			tempNNeighbors = nRoutingTable;
			tempIdNeighbor = op;
			if(op < nRoutingTable && op > 0){
				tempCostNeighbor = routingTable[op][0];
			}

			pthread_mutex_unlock(&routingTableMutex);
		}

		// Verifica se é possível enviar a mensagem para o destino escolhido
		if(op > tempNNeighbors || op < 1 || tempIdNeighbor < 1 || op == thisRotId  || tempCostNeighbor == INFINITY){
			printRed();
			printf("ERRO: Este vizinho não existe ou não é conhecido. Tente Novamente!\n");
			printReset();
		} else {
			char message[BUFLEN];
			// Pega mensagem criada pelo usuário
			printf("Insira a mensagem que deseja enviar (máximo de 100 caracteres): ");
			__fpurge(stdin);
			scanf("%[^\n]s",message);
			__fpurge(stdin);

			// Cria pacote com as informações escolhidas
			Packet newPacket;
			int packetId;
			if(pthread_mutex_lock(&newIdMutex) == 0) {
				packetId = newId;
				if(newId == INFINITY) {
					newId = 0;
				}
				newId++;

				pthread_mutex_unlock(&newIdMutex);
			}
			createPacket(packetId, &newPacket ,0, thisRotId, op, message);

			// Adiciona o Pacote na fila de Saída
			if(pthread_mutex_lock(&outputQueueMutex) == 0){
				outputQueue = addQueue(outputQueue, newPacket);
				pthread_mutex_unlock(&outputQueueMutex);
				sem_post(&outputQueueSemaphore);
			}

			return;
		}
    }	
}

void printKnownNeighbors() 
{
	printf("---------------------------------------------------------\n");
	printf("|\tID\t|\tCost\t|\tNext Hop\t|\n");
	printf("----------------+---------------+-----------------------|\n");

	// Percorre tabela de roteamento e mostra os destinos possíveis
	if(pthread_mutex_lock(&routingTableMutex) == 0){
		for(int i = 0; i < nRoutingTable; i++){
			if(routingTable[i][0] < INFINITY && i != thisRotId){
				printf("|\t%d\t|\t%d\t|\t\t%d\t|\n",i, routingTable[i][0], routingTable[i][1]);
			}
		}

		pthread_mutex_unlock(&routingTableMutex);
	}
	printf("---------------------------------------------------------\n");

}

// ##### Get initial config #####
void getRotConfig(int id)
{
	int finded = 0;

	// Lê o arquivo de configuração do roteador
	FILE *rotConfigFile = fopen("config/roteador.config", "r"); 
	if (rotConfigFile == NULL){
		printRed();
		printf("ERRO: Problemas na abertura do arquivo 'roteador.config'\n");
		printReset();
		exit(1);
	}

	int biggest = -1;
	int tempInfo[2];
	char tempRotIP[15];
	// Pega informação do maior ID e encontra o próprio ID (thisRotID) no arquivo
	while(fscanf(rotConfigFile, "%i %i %s", &tempInfo[0], &tempInfo[1], tempRotIP) != EOF){
		if(tempInfo[0]+1 > biggest){
			biggest = tempInfo[0]+1;
		}
		if(tempInfo[0] == id){
			finded = 1;
			thisRotId = tempInfo[0];
			thisRotPort = tempInfo[1];
			thisRotIp = tempRotIP;
		}
	}

	// Verifica se o ID selecionado ao rodar o programa existe no arquivo de config
	if(!finded){
		printRed();
		printf("ERRO: Não foi encontrado o roteador de id %i no arquivo 'roteador.config'\n", id);
		printReset();
		exit(1);
	}

	// Cria vetor de neighbor com tamanho do maior id+1
	neighbors = calloc(sizeof(Neighbor), biggest);
	nNeighbors = biggest;

	// Percorre vetor de neighbors e "zera" cada um com valores padrão
	for(int i = 0; i < nNeighbors; i++){
		neighbors[i].cost = INFINITY;
		neighbors[i].directLink = false;
	}

	// Ajusta informações do próprio roteador na estrutura de vizinhos
	neighbors[thisRotId].id = thisRotId;
	neighbors[thisRotId].port = thisRotPort;
	strcpy(neighbors[thisRotId].ip, thisRotIp);
	neighbors[thisRotId].cost = 0;
	neighbors[thisRotId].directLink = true;

	fclose(rotConfigFile);
}

void getNeighborsInfo(int id)
{
	int biggestCost = 0;

	// Lê o arquivo de configuração de enlaces
	FILE *enlacesConfigFile = fopen("config/enlaces.config", "r");
	if (enlacesConfigFile == NULL){
		printRed();
		printf("ERRO: Problemas na abertura do arquivo 'enlaces.config'\n");
		printReset();
		exit(1);
	}
	int tempInfo[3];

	// Percorre arquivo e pega as informações dos vizinhos baseado no id do roteador
	while(fscanf(enlacesConfigFile, "%i %i %i", &tempInfo[0], &tempInfo[1], &tempInfo[2]) != EOF){

		// Pega o maior custo para definir o valor de limite da contagem ao infinito
		if(tempInfo[2] > biggestCost){
			biggestCost = tempInfo[2];
		}

		if(tempInfo[0] == id || tempInfo[1] == id){	
			int neighborId;
			if(tempInfo[0] == id){
				neighborId = tempInfo[1];
			} else if(tempInfo[1] == id){
				neighborId = tempInfo[0];
			}

			// Cria novo vizinho com conexão direta configurando o custo de acordo com o arquivo
			Neighbor newNeighbor;
			newNeighbor.cost = tempInfo[2];
			newNeighbor.directLink = true;

			// Abre arquivo de configuração do roteador 
			FILE *rotConfigFile = fopen("config/roteador.config", "r"); 
			if (rotConfigFile == NULL){
				printRed();
				printf("ERRO: Problemas na abertura do arquivo 'roteador.config'\n");
				printReset();
				exit(1);
			}

			// Pega as informações de IP e Porta do vizinho
			while(fscanf(rotConfigFile, "%i %i %s", &newNeighbor.id, &newNeighbor.port, newNeighbor.ip) != EOF){
				if(newNeighbor.id == neighborId){
					neighbors[neighborId] = newNeighbor;
					setCountdownDistanceArray(neighborId);
					break;
				}
			}

			fclose(rotConfigFile);
		}
	}

	fclose(enlacesConfigFile);

	// Configura valor da contagem ao infinito
	countToInfinity = biggestCost * (nNeighbors-1);
}

void sendDistanceArray()
{
	char message[BUFLEN] = "";
	int *directLinksNeighbors;
	int nDirectLinksNeighbors;

	// Pega informações dos vizinhos com conexão direta com o roteador atual, para enviar o vetor distância
	if(pthread_mutex_lock(&neighborsMutex) == 0){
		directLinksNeighbors = malloc(nNeighbors * sizeof(int));
		nDirectLinksNeighbors = nNeighbors;
		for(int i = 0; i < nNeighbors; i++) {
			if(neighbors[i].id > 0 && neighbors[i].directLink && i != thisRotId){
				directLinksNeighbors[i] = neighbors[i].cost;
			} else {
				directLinksNeighbors[i] = INFINITY;
			}
		}
		pthread_mutex_unlock(&neighborsMutex);
	}

	// Cria vetor distância a partir da tabela de roteamento
	if(pthread_mutex_lock(&routingTableMutex) == 0){
		for(int i = 0; i < nRoutingTable; i++){
			if(routingTable[i][0] < INFINITY){
				char buffer[BUFLEN]="";

				sprintf(buffer, "%d:%d,", i, routingTable[i][0]);

				strcat(strcpy(message, message), buffer);
			}
		}
		pthread_mutex_unlock(&routingTableMutex);
	}

	// Cria um pacote com a mesma mensagem (vetor distância) para cada vizinho com conexão direta
	for(int i = 0; i < nDirectLinksNeighbors; i++){
		if(directLinksNeighbors[i] < INFINITY){
			Packet newPacket;
			int packetId;
			if(pthread_mutex_lock(&newIdMutex) == 0) {
				packetId = newId;
				if(newId == INFINITY) {
					newId = 0;
				}
				newId++;

				pthread_mutex_unlock(&newIdMutex);
			}
			createPacket(packetId, &newPacket, 1, thisRotId, i, message);

			if(pthread_mutex_lock(&outputQueueMutex) == 0){
				outputQueue = addQueue(outputQueue, newPacket);
				pthread_mutex_unlock(&outputQueueMutex);
				sem_post(&outputQueueSemaphore);
			}
		}		
	}
}

void setDistanceArray(Packet * toHandlePacket)
{
	if(pthread_mutex_lock(&distanceArraysMutex) == 0){	
		// Verifica se o vetor de vetores distância já foi criado ou não
		if(nDistanceArrays == 0){ // Cria vetor de vetores
			nDistanceArrays = toHandlePacket->sourceId+1;
			distanceArrays = malloc(nDistanceArrays * sizeof(int*));
			sizeEachDistanceArray = calloc(nDistanceArrays, sizeof(int));

			for(int i = 0; i < nDistanceArrays; i++){
				distanceArrays[i] = NULL;
			}
		} else if(nDistanceArrays < toHandlePacket->sourceId+1){ // Verifica se o ID é maior que o vetor de vetores distância
			int **auxArray = malloc((toHandlePacket->sourceId+1) * sizeof(int*));
			int *auxSizeEachDistanceArray = calloc((toHandlePacket->sourceId+1),sizeof(int));

			//Extende o vetor para utilizar o indíce do vetor como próprio id do roteador
			for(int i = 0; i < toHandlePacket->sourceId+1; i++){
				if(i < nDistanceArrays){
					auxArray[i] = distanceArrays[i];
					auxSizeEachDistanceArray[i] = sizeEachDistanceArray[i];
				} else {
					auxArray[i] = NULL;
				}
			}
			nDistanceArrays = toHandlePacket->sourceId+1;

			free(distanceArrays);
			free(sizeEachDistanceArray);
			distanceArrays = auxArray;
			sizeEachDistanceArray = auxSizeEachDistanceArray;
		}
		pthread_mutex_unlock(&distanceArraysMutex); // Libera o mutex
	}
	// Pega a mensagem do pacote
	char message[BUFLEN];
	strcpy(message, toHandlePacket->payload);

	int firstChar = 0;
	char *tuple;
	int *newDistanceArray = NULL;
	int nNewDArray = 0;

	// Cria um vetor baseado no payload do pacote que é extendido a cada tupla encontrada e adicionada no vetor
	for(int nChar = 0; nChar < strlen(message); nChar++) {
		if(message[nChar] == ','){
			tuple = calloc(nChar+1-firstChar,sizeof(char));
			strncpy(tuple, message+firstChar, nChar-firstChar);
			firstChar = nChar+1;

			if(newDistanceArray == NULL){
				nNewDArray += 2;
				newDistanceArray = calloc(nNewDArray, sizeof(int));
			} else {
				nNewDArray += 2;
				int *auxArray = calloc(nNewDArray, sizeof(int));

				for(int index = 0; index < nNewDArray-2; index++){
					auxArray[index] = newDistanceArray[index];
				}

				free(newDistanceArray);
				newDistanceArray = auxArray;
			}

			sscanf(tuple, "%d:%d", &newDistanceArray[nNewDArray-2], &newDistanceArray[nNewDArray-1]);

			free(tuple);
		}
	}
	if(pthread_mutex_lock(&distanceArraysMutex) == 0){	
		// Coloca o vetor distância na estrutura de vetores distância
		distanceArrays[toHandlePacket->sourceId] = newDistanceArray;
		sizeEachDistanceArray[toHandlePacket->sourceId] = nNewDArray;

		pthread_mutex_unlock(&distanceArraysMutex); // Libera o mutex
	}
}

void printDistanceArrays()
{
	if(pthread_mutex_lock(&distanceArraysMutex) == 0){
		printBlue();
		printf("\nVetores Distância:\n");
		printReset();
		// Percorre e verifica os vetores distância existentes e os imprime
		bool hasPrinted = false;
		for(int i = 0; i < nDistanceArrays; i++){
			if(distanceArrays[i] != NULL){
				printf("\tRoteador %d: ", i);
				for(int j = 0; j < sizeEachDistanceArray[i]; j+=2){
					printf("[%d, %d] ", distanceArrays[i][j], distanceArrays[i][j+1]);
				}
				hasPrinted = true;
				printf("\n");
			}
		}
		if(!hasPrinted) {
			printRed();
			printf("\tNenhum vetor distância foi encontrado\n");
			printReset();
		}
		printf("\n");

		pthread_mutex_unlock(&distanceArraysMutex);
	}
}

void setCountdownDistanceArray(int neighborId)
{
	if(pthread_mutex_lock(&countdownDistanceArraysMutex) == 0){
		// Verifica se a estrutura de contagem de tempo já existe
		if(sizeCountdownDA == 0){ // Se não existe, usa o ID do vizinho + 1 como tamanho inicial
			sizeCountdownDA = neighborId+1;
			countdownDistanceArrays = calloc(sizeCountdownDA,sizeof(time_t));
		} else if(sizeCountdownDA < neighborId+1){ // Verifica se o tamanho da estrutura é menor do que o ID do vizinho + 1, nesse caso, extende a estrutura.
			time_t *auxArray = calloc(neighborId+1,sizeof(time_t));

			for(int i = 0; i < sizeCountdownDA; i++){
				auxArray[i] = countdownDistanceArrays[i];
			}
			sizeCountdownDA = neighborId+1;
			free(countdownDistanceArrays);
			countdownDistanceArrays = auxArray;
		}

		// Pega informação do tempo atual e adiciona na estrutura
		countdownDistanceArrays[neighborId] =  time(NULL);

		pthread_mutex_unlock(&countdownDistanceArraysMutex); // Libera o mutex
	}
}

void printCountdownDA()
{
	if(pthread_mutex_lock(&countdownDistanceArraysMutex) == 0) {			
		printf("Coundowns:\n");
		// Percorre a estrutura de contagem de tempo e imprime as contagens existentes
		for(int i = 0; i < sizeCountdownDA; i++){
			if(countdownDistanceArrays[i] != 0){
				printf("Roteador %d: %ld\n", i, countdownDistanceArrays[i]);
			}
		}
		printf("\n\n");

		pthread_mutex_unlock(&countdownDistanceArraysMutex);
	}

}

void setRoutingTable()
{
	bool changed = false; // Se mudou algo nos custos, precisa mandar o vetor distancia para os vizinhos novamente.

	int biggestRoutID;
	if(pthread_mutex_lock(&neighborsMutex) == 0) { // Usado para estabelecer um tamanho para a tabela
		biggestRoutID = nNeighbors;
		pthread_mutex_unlock(&neighborsMutex);
	}

	if(pthread_mutex_lock(&distanceArraysMutex) == 0){ // Pega mutex
		// Verifica se não há um ID maior
		for(int i = 0; i < nDistanceArrays; i++){
			for(int j = 0; j < sizeEachDistanceArray[i]; j+=2){
				if(distanceArrays[i][j] > biggestRoutID){
					biggestRoutID = distanceArrays[i][j];
				}
			}
		}

		pthread_mutex_unlock(&distanceArraysMutex);
	}

	// Cria uma nova tabela com os valores padrão para ser preenchida
	int ** newRoutingTable = malloc(biggestRoutID * sizeof(int *));
	for(int k = 0; k < biggestRoutID; k++) {
		newRoutingTable[k] = calloc(2, sizeof(int));
		newRoutingTable[k][0] = INFINITY;
	}

	// Verifica se algum tempo estourou
	if(pthread_mutex_lock(&countdownDistanceArraysMutex) == 0){
		for(int j = 1; j < sizeCountdownDA; j++){
			time_t now = time(NULL);
			if(j != thisRotId && countdownDistanceArrays[j] != 0 && now - countdownDistanceArrays[j] > timeout*6){ // Se estourou o tempo
				if(pthread_mutex_lock(&neighborsMutex) == 0){ // Informa que não há mais conexão com o roteador pelo enlace direto
					if(nNeighbors > j){
						neighbors[j].directLink = false;	
					}
					pthread_mutex_unlock(&neighborsMutex);
				}
				if(pthread_mutex_lock(&distanceArraysMutex) == 0){ // Tira vetor distância do vizinho que estourou o tempo
					if(nDistanceArrays > j) {
						free(distanceArrays[j]);
						distanceArrays[j] = NULL;
						sizeEachDistanceArray[j] = 0;
					}
					pthread_mutex_unlock(&distanceArraysMutex);
				}
				countdownDistanceArrays[j] = 0;
			}
		}
		pthread_mutex_unlock(&countdownDistanceArraysMutex);
	}

	// Preenche tabela com informação dos vizinhos com ligação direta
	if(pthread_mutex_lock(&neighborsMutex) == 0) {
		for(int k = 1; k < nNeighbors; k++){
			if(neighbors[k].id > 0 && neighbors[k].directLink) {
				newRoutingTable[k][0] = neighbors[k].cost;
				newRoutingTable[k][1] = k;
			}
		}
		pthread_mutex_unlock(&neighborsMutex);
	}

	if(pthread_mutex_lock(&distanceArraysMutex) == 0) {
		if(nDistanceArrays > 0){ // Verifica se os vetores distância já existem para adicionar na tabela. 
			for(int i = 0; i < nDistanceArrays; i++){
				if(distanceArrays[i] != NULL){ // Verifica se há um vetor distância nesse indíce
					int neighborCost;

					// Pega o custo até o roteador do índice (Usado para calcular o custo dos vizinhos sem conexão direta)
					if(pthread_mutex_lock(&neighborsMutex) == 0){
						neighborCost = neighbors[i].cost;
						neighbors[i].directLink = true;

						pthread_mutex_unlock(&neighborsMutex);
					}

					for(int j = 0; j < sizeEachDistanceArray[i]; j+=2){
						int routId = distanceArrays[i][j], routCost = distanceArrays[i][j+1];

						if(newRoutingTable[i][0] < neighborCost) { // Verifica se já não há um custo menor na tabela de roteamento
							neighborCost = newRoutingTable[i][0];
						}

						// Preenche tabela se encontra caminho mais curto ou se encontra caminho para o roteador do índice
						if(routCost+neighborCost < newRoutingTable[routId][0]){
							if(routCost+neighborCost > countToInfinity) {
								newRoutingTable[routId][0] = INFINITY;
								newRoutingTable[routId][1] = 0;
							} else {
								newRoutingTable[routId][0] = routCost+neighborCost;
								newRoutingTable[routId][1] = i;
							}
						}
					}

				} 
			}
		}
		pthread_mutex_unlock(&distanceArraysMutex);
	}

	// Altera a tabela de roteamento para a nova tabela criada a partir dos vetores distância
	if(pthread_mutex_lock(&routingTableMutex) == 0){ 
		if(nRoutingTable != biggestRoutID) {
			changed = true;
			nRoutingTable = biggestRoutID;
		} else {
			for(int i = 0; i < nRoutingTable; i++) {
				if(routingTable[i][0] != newRoutingTable[i][0] || routingTable[i][1] != newRoutingTable[i][1]){
					changed = true;
				}
			}
		}

		// Se modificado, substitui tabela de roteamento pela nova criada
		if(changed){
			free(routingTable);
			routingTable = newRoutingTable;
		} else { // se não, limpa a nova tabela criada
			free(newRoutingTable);
		}

		pthread_mutex_unlock(&routingTableMutex);
	}

	// Se modificado, precisa mandar vetor distância novamente
	if(changed) {
		if(pthread_mutex_trylock(&terminalMutex) == 0) {
			printRoutingTable();
			pthread_mutex_unlock(&terminalMutex);
		}

		sendDistanceArray();
	}
}

void changeTimeout()
{
	int newTimeout;

	// Solicita novo intervalo para usuário
	printf("Insira o valor de intervalo desejado (default = 5): ");
	scanf("%d", &newTimeout);

	// Configura novo intervalo para o roteador
	if(pthread_mutex_lock(&countdownDistanceArraysMutex) == 0){
		timeout = newTimeout;
		pthread_mutex_unlock(&countdownDistanceArraysMutex);
	}
}

void printRoutingTable()
{
	printf(" ----------------------------------------------- \n");
	printf("| Router ID\t|\tCost\t| Next Hop\t|\n");
	printf("|---------------+---------------+---------------|\n");
	if(pthread_mutex_lock(&routingTableMutex) == 0){
		for(int i = 1; i < nRoutingTable; i++) {
			if(routingTable[i][0] == INFINITY){
				printf("|\t%d\t|\t∞\t|\t-\t|\n", i);
			} else {
				printf("|\t%d\t|\t%d\t|\t%d\t|\n", i, routingTable[i][0], routingTable[i][1]);
			}
		}
		pthread_mutex_unlock(&routingTableMutex);
	}
	printf(" ----------------------------------------------- \n");
	time_t clk = time(NULL);
	printf("%s\n", ctime(&clk));
}