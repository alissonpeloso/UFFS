#include "../headers/util.h"

void printRed(){
	printf("\033[0;31m");
	return;
}

void printYellow(){
	printf("\033[0;33m");
	return;
}

void printBlue(){
	printf("\033[0;34m");
	return;
}

void printGreen(){
	printf("\033[0;32m");
	return;
}

void printReset(){
	printf("\033[0m");
	return;
}

// ##### Socket functions #####
void die(char *s){
    perror(s);
    exit(1);
	return;
}
