#include "../headers/libs.h"

Queue *initQueue(Queue *queue) {
	queue = (Queue *)malloc(sizeof(Queue));
	queue->head = NULL;
	queue->tail = NULL;

	queue->size = 0;
	return queue;
}

Queue *addQueue(Queue *queue, Packet data) {
	Node *newNode = malloc(sizeof(Node));
	newNode->data = data;
	newNode->next = NULL;
	newNode->prev = NULL;

	if (queue->size == 0) {
		queue->head = newNode;
		queue->tail = newNode;
	} else {
		queue->tail->next = newNode;
		newNode->prev = queue->tail;
		queue->tail = newNode;
	}
	queue->size += 1;
  	return queue;
}

Queue *rmQueue(Queue *queue) {
	if (queue->size == 0) {
		printf("Fila vazia, impossível remover!\n");
		return queue;
	}
	Node *toRemove = queue->head;
	if (queue->size == 1) {
		queue->head = NULL;
		queue->tail = NULL;
	} else {
		queue->head = toRemove->next;
		queue->head->prev = NULL;
	}
	free(toRemove);
	queue->size -= 1;
	return queue;
}

void printQueue(Queue *queue) {
	Node *printer = queue->head;
	printf("==========================================\n");
	printf("\tn\t|\tdata\n");
	printf("================+=========================\n");

	for (int i = 0; i < queue->size; i++) {
		printf("\t%d\t|", i);
		printf("\t%s\n", printer->data.payload);
		printer = printer->next;
	}
	printf("==========================================\n");
	printf("size: %d\n", queue->size);
	printf("\n");
	return;
}