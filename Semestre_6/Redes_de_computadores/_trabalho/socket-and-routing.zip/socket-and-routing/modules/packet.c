#include "../headers/libs.h"

void createPacket(int id, Packet *newPacket, int type, int sourceId, int destinationId, char * payload){ // Cria um novo pacote (tipo de construtor)
	newPacket->id = id;
	newPacket->type = type;
	newPacket->sourceId = sourceId;
	newPacket->destinationId = destinationId;
	strcpy(newPacket->payload, payload);

	return;
}