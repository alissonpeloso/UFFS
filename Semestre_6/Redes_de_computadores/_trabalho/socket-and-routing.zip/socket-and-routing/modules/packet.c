#include "../headers/libs.h"

void createPacket(Packet *newPacket, int type, int sourceId, int destinyId, char * payload){
	newPacket->type = 0;
	newPacket->sourceId = sourceId;
	newPacket->destinyId = destinyId;
	strcpy(newPacket->payload, payload);

	return;
}