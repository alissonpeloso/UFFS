#include <stdio.h>
#include <stdlib.h>

void uppercase(char *string, int size){
    for(int i = 0; i < size; i++){
        string[i] = toupper(string[i]);
    }
}

int main(int argc, char const *argv[])
{
    FILE *file;

    file = fopen("test.txt","r");
    if (file == NULL){
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }

    char a[100];

    fgets(a,sizeof(a),file);

    uppercase(a,sizeof(a));

    fclose(file);

    file = fopen("newText.txt","a");
    if (file == NULL){
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }

    fprintf(file, "%s", a);

    fclose(file);
   
    return 0;
}
