#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    FILE *file;

    char f[20];
    printf("Insira o nome do Arquivo: ");
    scanf("%s", &f);

    file = fopen(f,"r");
    if (file == NULL){
        printf("Erro ao abrir arquivo.\n");
        return 1;
    }

    int nWords = 0;
    char space[] = {" "};
    char lineBreak[] = {"\n"};      
    
    while(!feof(file)) {
        char *c = fgetc(file);
        if(c == ' ' || c == '\n'){
            nWords++;
        }
    }   
    
    printf("Número de palavras do arquivo %s: %d\n", f,nWords);

    fclose(file);

    return 0;
}
