from func import *

a = float(input('Insira o primeiro valor: '))
b = float(input('Insira o segundo valor: '))
print('O maior valor é:',min(a,b))
