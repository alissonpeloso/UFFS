from func import *

a = int(input('Insira um número e direi o seu valor fatorial: '))
print('Resposta:',fat(a))
