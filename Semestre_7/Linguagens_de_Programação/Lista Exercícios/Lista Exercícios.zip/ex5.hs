func :: Float -> Float -> Float -> Float
func a b c = a * b * c