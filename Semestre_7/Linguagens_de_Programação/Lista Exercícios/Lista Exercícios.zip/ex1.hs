salario :: Float -> Float
salario a = a - (0.07 * a) + (0.1 * a)